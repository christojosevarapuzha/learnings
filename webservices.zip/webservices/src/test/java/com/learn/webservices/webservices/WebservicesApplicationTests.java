package com.learn.webservices.webservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
